import React from 'react'
import Header from '../components/Header'

const Contact = () => {
  return (
    <Header />
  )
}

export default Contact